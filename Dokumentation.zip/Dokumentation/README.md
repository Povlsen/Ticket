Ticket
H1 Projekt
Medlemmer af gruppen:
Seppi Haaland Damgaard
Mikkel Norre Nielsen
Nikolai Risgaard Thorup Povlsen

Fag som bliver inkulederet:
Grundlæggende programming
Versionering og dokumentation
Database programmering
Client Side programmering

Projektet kommer til at bestå af et online ticket system, hvor en bruger kan logge ind og oprette en ticket som en administrator kan se når de er logget ind.


